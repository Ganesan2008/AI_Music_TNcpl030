import streamlit as st
import requests

API_URL = "http://127.0.0.1:8000/generate_music/"

st.title('Music Generator')

# Text input for user to type the emoji or description
input_text = st.text_input("Enter Emoji or Description:", "")

if st.button('Generate Music'):
    if input_text:
        # Make a POST request to FastAPI
        response = requests.post(API_URL, json={"input_text": input_text})
        if response.status_code == 200:
            # Assuming the API returns the path to the audio file
            audio_file = response.content
            st.audio(audio_file)
        else:
            st.error("Failed to generate music: " + response.text)
    else:
        st.error("Please enter some text to generate music.")