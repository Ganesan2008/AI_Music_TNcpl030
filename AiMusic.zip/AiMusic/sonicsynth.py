from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.responses import FileResponse
from pydantic import BaseModel
import numpy as np
import scipy.io.wavfile
import tempfile
import csv
import os
from transformers import pipeline
from cachetools import cached, TTLCache

app = FastAPI()
cache = TTLCache(maxsize=100, ttl=3600)  # Cache for audio data

class RequestModel(BaseModel):
    input_text: str

# Initialize the synthesizer outside of the function to avoid reloading it each time
synthesizer = pipeline("text-to-audio", model="facebook/musicgen-small", device="cpu")

@cached(cache)
def generate_audio(description: str):
    music = synthesizer(description, forward_params={"do_sample": True})
    audio_data = np.asarray(music["audio"], dtype=np.float32)
    # Normalize audio to prevent clipping
    audio_data /= np.max(np.abs(audio_data), axis=0)
    audio_data_int16 = np.int16(audio_data * 32767)
    return music["sampling_rate"], audio_data_int16

def load_emoji_descriptions(csv_file_path):
    emoji_to_description = {}
    with open(csv_file_path, mode='r', encoding='utf-8') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            emoji_to_description[row['Emoji(s)']] = row['Description']
    return emoji_to_description

@app.post("/generate_music/")
async def generate_music_endpoint(request: RequestModel, background_tasks: BackgroundTasks):
    input_text = request.input_text.strip()
    if not input_text:
        raise HTTPException(status_code=400, detail="Input text is required")

    descriptions = load_emoji_descriptions(r"C:\Users\prasa\OneDrive\Desktop\your project\venv\my project\emojis.csv")
    description = descriptions.get(input_text, input_text)

    try:
        sampling_rate, audio_data_int16 = generate_audio(description)
        temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.wav')
        scipy.io.wavfile.write(temp_file.name, rate=sampling_rate, data=audio_data_int16)
        temp_file.close()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to generate audio: {str(e)}")

    response = FileResponse(path=temp_file.name, media_type='audio/wav', filename="generated_audio.wav")
    background_tasks.add_task(os.unlink, temp_file.name)
    return response
